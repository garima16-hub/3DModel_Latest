﻿using System;
using System.Collections.Generic;

namespace _3DModels.Models
{
    public partial class Admin
    {
        public string AdminName { get; set; }
        public string Contact { get; set; }
        public string emailId { get; set; }
        public string password { get; set; }
        public string Role { get; set; }
    }
}




